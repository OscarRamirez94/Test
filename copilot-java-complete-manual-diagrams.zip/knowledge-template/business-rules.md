# Business Rules

Record durable cross-flow business rules. Keep flow-specific rules in `flows/` when possible.
