# Flow Knowledge

Create one concise Markdown file per important flow. Include entry point, use case, ports, adapters, external dependencies, business rules and error behavior.
