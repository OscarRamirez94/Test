# Project Conventions

Record repository-specific naming, packages, mapping, error, reactive, logging and testing conventions.
