# Diagrams

This folder is intentionally manual-only. Create or update diagrams here only when the user explicitly requests a diagram or visualization.
