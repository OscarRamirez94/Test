# Technical Decisions

Record durable decisions and rationale. Update or supersede stale decisions explicitly.
