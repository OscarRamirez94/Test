# Architecture

Keep this concise. Record stable layer boundaries, dependency direction and major architectural patterns.

Do not add diagrams here unless explicitly requested.
