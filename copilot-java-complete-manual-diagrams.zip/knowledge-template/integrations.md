# Integrations

Record external REST/SOAP/Redis/etc. integrations, owning adapters and important contracts.
