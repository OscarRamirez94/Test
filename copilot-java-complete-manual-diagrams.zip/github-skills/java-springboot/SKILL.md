---
name: java-springboot
description: Apply Spring Boot best practices when creating, extending, debugging or refactoring Java application flows.
---
# Spring Boot
Follow existing project conventions before introducing new patterns.
Prefer constructor injection, cohesive responsibilities, externalized configuration and clear naming.
Preserve behavior during refactors.
Inspect sibling flows before creating new components.
Avoid unnecessary abstractions and unrelated changes.
Check bean wiring, imports, configuration properties and compatibility after changes.
