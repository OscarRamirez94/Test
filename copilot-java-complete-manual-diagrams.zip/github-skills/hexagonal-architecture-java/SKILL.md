---
name: hexagonal-architecture-java
description: Create and refactor Java/Spring applications using Hexagonal Architecture, use cases, input/output ports and infrastructure adapters.
---
# Hexagonal Architecture
Dependencies point inward.

Domain: business models/rules, no infrastructure.
Application: use cases, orchestration, ports.
Infrastructure: controllers, WebClient, SOAP, Redis, repositories, external integrations.

Do not leak WebClient, RedisTemplate, SOAP-generated types or transport concerns into domain logic.

For new flows, find an analogous flow first. Reuse a port only when it represents the same capability. Create abstractions only for meaningful boundaries.
