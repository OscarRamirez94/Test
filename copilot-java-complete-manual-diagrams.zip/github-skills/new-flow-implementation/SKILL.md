---
name: new-flow-implementation
description: Design and implement new Java/Spring flows end-to-end using existing project conventions, WebFlux, hexagonal architecture, integrations, OpenAPI and tests.
---
# New Flow Implementation
Before creating code, find the closest analogous flow and learn its package layout, naming, DTOs, ports, adapters, error strategy, OpenAPI and tests.

Design:
Endpoint -> validation/mapping -> use case -> output ports -> adapters -> external systems -> result -> response.

Rules:
- Create only necessary files.
- Reuse existing capabilities when semantically appropriate.
- Keep infrastructure out of domain/application.
- Keep reactive execution non-blocking.
- Determine whether multiple async calls are dependent or can run concurrently.
- Implement expected error and empty-result behavior explicitly.
- Add/update OpenAPI and tests when applicable.
- Respect normal IDE confirmation/approval controls.
- Do not generate or update diagrams unless the user explicitly asks for a diagram.
