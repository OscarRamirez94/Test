---
name: code-review
description: Review Java/Spring changes after implementation for correctness, regressions, architecture, reactive semantics, maintainability, tests and API compatibility.
---
# Code Review
Review the actual diff and affected flow, not only isolated files.

Prioritize:
1. correctness/regressions
2. business-rule preservation
3. reactive correctness
4. architecture boundaries
5. error/empty semantics
6. API compatibility
7. tests
8. maintainability

Report concrete findings with file/location and suggested correction. Avoid style-only noise unless it affects maintainability.
