---
name: project-conventions
description: Discover and follow repository-specific Java/Spring conventions when refactoring existing flows or creating new ones.
---
# Project Conventions
Before substantial work, inspect analogous code in this repository.

Learn and follow:
- package/layer structure
- naming of controllers/use cases/ports/adapters
- DTO and mapper conventions
- exception/error model
- Reactor patterns
- logging/observability
- configuration
- OpenAPI style
- test style

Repository code is the source of truth. Do not invent a competing convention unless explicitly asked to redesign it.

When a durable convention is discovered, record it in the project knowledge files if that knowledge system is present.
