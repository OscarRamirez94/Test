---
name: rest-webclient-integration
description: Create and refactor non-blocking REST integrations using Spring WebClient, DTO mapping, headers, parameters and error handling.
---
# REST / WebClient
Keep outbound transport in infrastructure adapters.
Reuse project WebClient configuration, filters, TLS, timeouts and error conventions.
Handle success, expected 4xx/5xx and empty bodies deliberately.
Map transport DTOs at adapter boundaries.
Never log credentials/tokens and never block the reactive chain.
