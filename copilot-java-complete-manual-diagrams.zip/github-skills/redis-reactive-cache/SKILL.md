---
name: redis-reactive-cache
description: Create and refactor reactive Redis cache/session flows using ReactiveRedisTemplate, hashes, TTL, serialization and cache-aside patterns.
---
# Reactive Redis
Use reactive APIs without block() or unmanaged subscribe().
Be explicit about keys, hashes, serialization, TTL and update semantics.

Cache-aside:
lookup -> return hit OR call source -> map -> persist -> TTL -> return.

Keep cache writes in the reactive chain. Preserve unrelated hash fields when required and refresh TTL only according to the contract.
