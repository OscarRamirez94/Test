---
name: manual-architecture-diagrams
description: Generate or update architecture and flow diagrams only when the user explicitly asks for a diagram, visual map, Mermaid diagram, architecture map, or flow visualization.
---
# Manual Architecture Diagrams

## Activation rule

ONLY use this skill when the user explicitly asks to:
- generate a diagram
- create an architecture diagram
- create a flow diagram
- map a flow visually
- create Mermaid
- update an existing diagram
- visualize controllers, use cases, ports, adapters or integrations

NEVER generate or update diagrams automatically during:
- refactoring
- new flow implementation
- debugging
- code review
- testing
- security review
- knowledge maintenance
- architecture analysis without an explicit diagram request

## Source of truth

Before generating a diagram:
1. Inspect the relevant current source code.
2. Read relevant `.github/knowledge/` files if present.
3. Verify class names and relationships against code.
4. Do not invent dependencies.

## Preferred output

Prefer Mermaid for repository-stored diagrams.

For an end-to-end flow, include only relevant nodes:
Controller/Router
-> Mapper/Validation
-> Use Case
-> Port(s)
-> Adapter(s)
-> External systems
-> Response

Include filters/context/error handlers only when they materially affect the requested flow.

## Storage

Only create or update diagram files if the user explicitly asks to persist them.

Suggested location:
`.github/knowledge/diagrams/`

Use concise filenames such as:
- `token-inq-flow.md`
- `account-detail-flow.md`
- `architecture-overview.md`

Do not update diagrams merely because code changed unless the user explicitly asks.
