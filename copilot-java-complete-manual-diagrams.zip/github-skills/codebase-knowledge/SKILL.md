---
name: codebase-knowledge
description: Maintain a compact repository knowledge map for Java/Spring architecture, flows, integrations, business rules and durable technical decisions to reduce repeated codebase rediscovery.
---
# Codebase Knowledge
Use `.github/knowledge/` as a compact index, never as a replacement for source code.

Before a broad refactor/new flow:
1. Read only the relevant knowledge files.
2. Verify important facts against current source code.
3. Work from the real code.

After discovering a durable architectural convention, business rule, integration contract or important flow change, update the relevant knowledge file.

Keep knowledge concise. Link/name concrete classes and flows. Do not copy source code wholesale. Remove/update stale statements when contradicted by code.

Suggested files:
- architecture.md
- conventions.md
- integrations.md
- business-rules.md
- decisions.md
- flows/<flow>.md

For each flow capture entry point, use case, ports, adapters, dependencies, key business rules and important error behavior.

Do not create or update architecture diagrams unless the user explicitly asks for a diagram.
