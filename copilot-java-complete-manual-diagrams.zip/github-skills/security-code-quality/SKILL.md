---
name: security-code-quality
description: Review Java/Spring changes for secure coding and quality, including XXE, SSRF, secrets, sensitive logging, validation, error handling and SAST concerns.
---
# Security / Quality
Never expose secrets, tokens, passwords, private keys or authorization headers.
For XML disable unsafe DTD/external entity behavior.
For outbound URLs avoid uncontrolled user-selected hosts; use configured/validated destinations.
Fix underlying security dataflows rather than scanner-only symptoms.
Check duplication, broad catches, dead code, hidden side effects and unnecessary complexity.
