---
name: flow-refactoring
description: Analyze and refactor complete Java/Spring flows end-to-end across controllers, use cases, ports, adapters, integrations, mappers, errors and tests.
---
# Complete Flow Refactoring
Use for refactors of existing flows.

Before editing:
1. Trace controller/router -> mapper -> use case -> ports -> adapters -> external systems -> response.
2. Inspect filters/context, error handling, configuration and tests.
3. Identify business rules and behavior that must remain unchanged.
4. Present a concise plan and affected files before broad changes.

During implementation:
- Preserve public contracts unless explicitly requested.
- Keep architecture boundaries.
- Maintain end-to-end reactive semantics.
- Avoid block(), unmanaged subscribe(), unrelated cleanup and speculative abstractions.
- Reuse established project patterns.
- Make incremental, reviewable edits and respect normal IDE approval/confirmation controls.
- Do not generate or update diagrams unless the user explicitly asks for a diagram.

After changes:
- Update affected tests.
- Check compilation/imports/types.
- Validate reactive error and empty-result semantics.
