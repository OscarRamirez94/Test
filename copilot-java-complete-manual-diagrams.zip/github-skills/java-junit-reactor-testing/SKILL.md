---
name: java-junit-reactor-testing
description: Create and refactor Java/Spring unit tests with JUnit 5, Mockito, Reactor Test and StepVerifier for use cases, adapters, controllers and mappers.
---
# Testing
Prefer JUnit 5 + Mockito + StepVerifier and follow existing project conventions.

Cover relevant:
- success
- empty publisher
- fallback
- expected business error
- downstream error
- important port interactions
- mapper edge cases

Avoid block() just to simplify reactive tests.
Do not weaken assertions merely to make tests pass.
Do not over-verify implementation details.
