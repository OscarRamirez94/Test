---
name: spring-webflux-reactor
description: Create, debug and refactor Spring WebFlux and Project Reactor flows using Mono, Flux, WebClient, Reactor Context, concurrency and reactive error handling.
---
# Spring WebFlux / Reactor
Maintain end-to-end non-blocking execution.

Prefer map for synchronous transforms, flatMap for dependent async work, zip/zipWhen for independent async results, switchIfEmpty for semantic empty fallback, and defer/deferContextual for deferred/context-aware work.

Avoid block(), Thread.sleep(), Future.get() and subscribe() in business flows.

For list enrichment use Flux.fromIterable(...).flatMap(...) with deliberate concurrency when appropriate. Never interpret concurrency as a record limit.

Preserve Reactor Context for session/token/trace metadata.

Error recovery must be intentional; preserve business exceptions and existing response semantics.
