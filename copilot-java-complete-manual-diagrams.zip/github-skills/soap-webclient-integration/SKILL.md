---
name: soap-webclient-integration
description: Create and refactor Java/Spring SOAP integrations, WebClient transport, SOAP envelopes, JAXB/SAAJ, secure XML parsing and SOAP faults.
---
# SOAP
Keep SOAP/generated classes in infrastructure and map at adapter boundaries.
Maintain reactive HTTP transport.
Handle HTTP errors, SOAP Faults, malformed XML and missing nodes deliberately.
Disable unsafe DTD/external entity resolution for XML parsing.
Preserve the application's established exception/body semantics.
