---
name: openapi-api-contracts
description: Create and maintain OpenAPI documentation for Spring Boot endpoints, DTO schemas, headers, path/query parameters, examples and errors.
---
# OpenAPI
Keep documentation synchronized with actual behavior.
Document relevant parameters, headers, request body, success and error responses.
Follow project annotation/style conventions.
When DTO/API contracts change, update schemas/examples accordingly.
