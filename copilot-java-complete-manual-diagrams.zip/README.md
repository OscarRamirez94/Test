# Copilot Java Complete Pack - Manual Diagrams

This version keeps diagram generation manual-only.

## Install

1. In your repository create `.github/skills/` if it does not exist.
2. Copy every folder inside `github-skills/` into `.github/skills/`.
3. Optional knowledge map: create `.github/knowledge/` and copy the contents of `knowledge-template/` there.
4. Continue using the normal GitHub Copilot Agent in IntelliJ.

## Important behavior

The `manual-architecture-diagrams` skill must only activate when you explicitly ask for a diagram or visualization.

Normal prompts such as:
- "Refactoriza este flujo"
- "Crea un nuevo flujo"
- "Revisa este endpoint"

must NOT create or update diagrams.

Explicit prompts such as:
- "Genera el diagrama de este flujo"
- "Crea un Mermaid del endpoint"
- "Actualiza el diagrama de arquitectura"

may use the diagram skill.

## Main skills

- flow-refactoring
- new-flow-implementation
- spring-webflux-reactor
- hexagonal-architecture-java
- java-springboot
- java-junit-reactor-testing
- rest-webclient-integration
- soap-webclient-integration
- redis-reactive-cache
- openapi-api-contracts
- security-code-quality
- code-review
- project-conventions
- codebase-knowledge
- manual-architecture-diagrams
