# Copilot Java Skills Pack

Paquete orientado a GitHub Copilot Agent en IntelliJ para proyectos Java/Spring.

Prioridades:
- refactorizar flujos completos
- crear nuevos flujos
- Spring Boot
- WebFlux / Reactor
- Arquitectura Hexagonal
- REST / SOAP
- Redis
- OpenAPI
- JUnit / Mockito / StepVerifier
- seguridad y calidad

Instalación:
1. Copia la carpeta `.github/skills` a la raíz de tu repositorio.
2. Sigue usando el Agent normal de GitHub Copilot.
3. Copilot elegirá las skills relevantes según la tarea y sus descripciones.
4. Para tareas críticas puedes mencionarlas explícitamente, por ejemplo:
   "Refactoriza el flujo completo usando las skills de WebFlux y arquitectura hexagonal."

Skills principales para tus tareas frecuentes:
- flow-refactoring
- new-flow-implementation

Las demás complementan automáticamente según el contexto.
