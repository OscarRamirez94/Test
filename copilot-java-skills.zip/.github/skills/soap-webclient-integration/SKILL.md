---
name: soap-webclient-integration
description: Create and refactor SOAP integrations in Java/Spring, including reactive WebClient transport, SOAP envelopes, JAXB/SAAJ mapping, secure XML parsing, SOAP faults, and adapter boundaries.
---

# SOAP Integration

Use this skill for SOAP adapters and new SOAP flows.

## Boundaries

Keep SOAP-specific generated/request/response classes in infrastructure.

Map SOAP models to application/domain DTOs at the adapter boundary.

Do not leak SOAP envelopes or generated classes into business logic unless the project already intentionally does so.

## Reactive transport

When SOAP is transported with WebClient:
- keep HTTP transport non-blocking
- isolate any unavoidable blocking XML operation if required by library behavior
- do not call block() in the normal reactive chain

## XML security

Disable unsafe external entity and DTD processing when parsing XML.

Avoid insecure parser defaults.

Do not accept arbitrary external entity resolution.

## Fault handling

Handle:
- HTTP errors
- SOAP Faults
- malformed XML
- missing expected nodes

Preserve the application's expected exception/body semantics.
