---
name: new-flow-implementation
description: Design and implement new Java/Spring application flows end-to-end using existing project conventions, Spring Boot, WebFlux, hexagonal architecture, ports/adapters, integrations, DTOs, mapping, errors, OpenAPI, and tests.
---

# New Flow Implementation

This is a primary skill when adding a new endpoint, use case, integration, or business flow.

## First: learn from the repository

Before creating files:
1. Find an analogous existing flow.
2. Identify package conventions.
3. Identify controller/router style.
4. Identify DTO/model conventions.
5. Identify use-case and port patterns.
6. Identify adapter patterns.
7. Identify mapper conventions.
8. Identify exception handling.
9. Identify OpenAPI style.
10. Identify testing style.

Use existing conventions as the default.

## Design the flow

Trace the intended path:

Endpoint
→ Request mapping/validation
→ Use Case
→ Output Port(s)
→ Adapter(s)
→ External system(s)
→ Domain/Application result
→ Response mapping

If multiple async services are involved, determine whether they can run concurrently or must be sequential.

## Implementation

Create only necessary files.

Prefer reuse over duplication.

Keep infrastructure details outside business logic.

Maintain reactive semantics end to end.

Add/update:
- DTOs
- mappers
- ports
- use cases
- adapters
- configuration
- controller/router
- OpenAPI
- tests

only where needed.

## Completion

A new flow is not complete until:
- main behavior is implemented
- expected errors are handled
- affected tests exist
- API documentation is updated when applicable
- compilation consistency has been checked
