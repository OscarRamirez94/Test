---
name: spring-security-quality
description: Review Java/Spring code for secure coding, Checkmarx/SAST concerns, XXE, SSRF, secrets, logging risks, validation, dependency boundaries, and safe refactoring.
---

# Security and Code Quality

Use this skill whenever a new external integration, XML parser, URL handling, sensitive header, authentication/session flow, or security finding is involved.

## Security

Never expose:
- passwords
- access tokens
- private keys
- session secrets
- authorization headers

Avoid logging sensitive payloads.

## XXE

For XML parsing:
- disable DTDs where possible
- disable external entities
- disable external schema resolution unless explicitly required and safely constrained

## SSRF

Do not construct arbitrary outbound URLs from uncontrolled user input.

Prefer allow-listed/configured hosts and validated path/query values.

## Refactoring security findings

Fix the underlying dataflow, not just the scanner pattern.

Preserve behavior while reducing the attack surface.

## Quality

Also check:
- duplicated logic
- dead code
- misleading naming
- broad exception catches
- hidden side effects
- unnecessary complexity
- thread-safety issues
