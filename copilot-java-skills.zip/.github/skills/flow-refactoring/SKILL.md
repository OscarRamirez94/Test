---
name: flow-refactoring
description: Analyze and refactor complete Java/Spring application flows end-to-end, especially endpoints spanning controllers, use cases, ports, adapters, REST/SOAP/Redis integrations, mappers, error handling, and tests.
---

# Complete Flow Refactoring

This is a primary skill for large refactor requests.

Do not refactor from a single file without tracing the full flow.

## Required analysis

Identify:
1. Entry endpoint/controller/router.
2. Request DTO and validation.
3. Filters/interceptors/context.
4. Mapper(s).
5. Use case/application service.
6. Input/output ports.
7. Infrastructure adapters.
8. External REST/SOAP/Redis/database calls.
9. Error handling.
10. Response mapping.
11. Existing tests.

## Refactor plan

Before a broad refactor, summarize:
- current flow
- concrete problems
- proposed design
- files likely affected
- risks/behavior that must remain unchanged

Then implement incrementally.

## Refactor priorities

Prefer:
- simpler control flow
- correct reactive composition
- clear responsibilities
- reduced duplication
- cohesive methods
- explicit error semantics
- reusable mapping where justified
- maintained architecture boundaries

Avoid:
- unnecessary framework rewrites
- changing unrelated flows
- speculative abstractions
- repository-wide formatting changes
- public contract changes without explicit intent

After production changes, update affected tests.
