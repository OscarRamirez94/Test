---
name: java-springboot
description: Apply Spring Boot best practices when creating, extending, or refactoring Java application flows, components, configuration, services, controllers, adapters, and integrations.
---

# Java Spring Boot

Use this skill whenever the task involves creating or refactoring Spring Boot code.

## Goals

- Preserve existing business behavior unless the task explicitly changes it.
- Prefer small, reviewable changes over broad rewrites.
- Follow existing project conventions before introducing new patterns.
- Keep responsibilities focused and avoid unnecessary abstractions.
- Reuse existing configuration, beans, utilities, mappers, and error models when appropriate.
- Keep configuration externalized.
- Avoid hidden side effects.

## Before modifying code

1. Inspect the relevant endpoint or entry point.
2. Trace the complete execution flow.
3. Identify related DTOs, mappers, use cases, ports, adapters, configuration and tests.
4. Determine whether the task is a refactor, bug fix, or a new flow.
5. Identify existing conventions in sibling flows and follow them unless they are clearly problematic.

## When creating a new flow

Prefer extending the existing project structure instead of inventing a new architecture.

Check for an analogous existing flow and reuse:
- package layout
- naming conventions
- exception strategy
- DTO conventions
- validation
- mapping patterns
- observability/logging
- testing style
- configuration style

Create only the files that are actually necessary.

## When refactoring

- Preserve API contracts unless explicitly asked to change them.
- Avoid unrelated cleanup.
- Do not rename public contracts casually.
- Reduce duplication where it improves maintainability.
- Keep methods cohesive.
- Prefer constructor injection.
- Avoid mutable shared state.
- Prefer clear domain-oriented naming.

## Validation

After changes, verify:
- imports
- bean wiring
- configuration properties
- compilation consistency
- tests impacted by the change
- backward compatibility of public contracts
