---
name: redis-reactive-cache
description: Create and refactor reactive Redis caching/session flows using Spring Data Redis, ReactiveRedisTemplate, hashes, TTL, serialization, cache fallback, and non-blocking access.
---

# Reactive Redis

Use this skill when a flow reads or writes Redis.

## Rules

Prefer reactive Redis APIs in reactive applications.

Do not block Redis calls.

Be explicit about:
- key format
- hash structure
- serialization
- TTL
- overwrite/update behavior
- cache miss behavior

## Cache-aside flow

Typical pattern:

Redis lookup
→ if found, map and return
→ if missing, call source system
→ map result
→ store result
→ apply/refresh TTL
→ return result

Ensure the cache write is part of the reactive chain rather than triggered by an unmanaged `subscribe()`.

## Hash updates

When updating structured session/hash data:
- avoid accidental duplicate/stale fields
- preserve unrelated fields when required
- refresh TTL intentionally if that is the contract

Do not leak Redis-specific models into domain code.
