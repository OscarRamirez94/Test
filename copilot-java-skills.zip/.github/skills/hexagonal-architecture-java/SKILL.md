---
name: hexagonal-architecture-java
description: Create and refactor Java/Spring flows following Hexagonal Architecture, Ports and Adapters, use cases, domain boundaries, input/output ports, and infrastructure adapters.
---

# Hexagonal Architecture for Java

Use this skill when creating or refactoring complete application flows.

## Dependency direction

Dependencies must point inward.

Domain:
- business models
- business rules
- domain errors
- no infrastructure dependencies

Application:
- use cases
- orchestration
- input/output ports
- business flow coordination

Infrastructure:
- REST controllers
- WebClient clients
- SOAP clients
- Redis
- repositories
- external systems
- framework-specific configuration

## Flow analysis

For an existing endpoint, trace:

Controller or Router
→ Input DTO
→ Mapper
→ Use Case
→ Output Port(s)
→ Adapter(s)
→ External system(s)
→ Response mapping

Also inspect filters, session/context propagation, error handling and tests.

## Creating new flows

Before creating new classes:
1. Find the closest analogous flow.
2. Reuse existing package boundaries.
3. Reuse existing ports when the business capability is actually the same.
4. Create a new port only when it represents a distinct boundary/capability.
5. Keep external DTOs out of the domain when possible.
6. Map infrastructure models at adapter boundaries.

## Refactoring

Do not move framework-specific classes into the domain.

Avoid:
- WebClient in use cases
- RedisTemplate in domain/application
- SOAP-generated classes in domain
- Controller DTOs leaking through every layer

Do not create interfaces just to satisfy a pattern. Interfaces should represent meaningful boundaries.

Keep use cases focused on orchestration and business decisions.
