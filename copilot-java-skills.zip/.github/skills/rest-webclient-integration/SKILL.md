---
name: rest-webclient-integration
description: Create and refactor reactive REST integrations in Spring Boot using WebClient, request/response DTOs, headers, path/query parameters, mapping, error handling, resiliency, and non-blocking execution.
---

# Reactive REST Integrations

Use this skill for outbound REST adapters and new REST flows.

## Adapter responsibilities

A REST adapter should:
- build the outbound request
- set required headers/path/query parameters
- call the external service
- map transport DTOs to application/domain models
- translate transport errors according to project rules

Do not place business orchestration in the adapter.

## WebClient

Prefer a configured/reused WebClient or builder provided by the project.

Do not block.

Handle:
- 2xx success
- expected 4xx errors
- 5xx errors
- empty body when meaningful
- timeouts if project conventions require them

Do not log secrets, authorization headers, tokens, or sensitive payloads.

## New integrations

Before creating a new client:
- inspect existing clients
- reuse common filters/configuration
- reuse error decoders/mappers when appropriate
- follow existing timeout and TLS configuration
