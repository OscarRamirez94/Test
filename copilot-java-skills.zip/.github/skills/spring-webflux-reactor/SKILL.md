---
name: spring-webflux-reactor
description: Design, create, debug, and refactor reactive Spring WebFlux flows using Project Reactor, Mono, Flux, Reactor Context, WebClient, non-blocking composition, concurrency, and reactive error handling.
---

# Spring WebFlux and Reactor

Use this skill for any reactive endpoint, use case, integration, adapter, filter, or test.

## Core rules

Maintain end-to-end non-blocking execution.

Prefer:
- Mono
- Flux
- map
- flatMap
- concatMap
- zip
- zipWhen
- switchIfEmpty
- onErrorMap
- onErrorResume
- defer
- contextWrite
- deferContextual

Avoid inside application flows:
- block()
- subscribe()
- Thread.sleep()
- Future.get()
- blocking file/database/network clients

Never call subscribe() from business code merely to trigger a side effect.

## Refactoring reactive flows

Before changing operators, determine:
- whether operations are sequential or independent
- whether ordering matters
- whether empty publishers are meaningful
- which exceptions must propagate unchanged
- whether fallback behavior is expected
- whether Reactor Context is required
- whether concurrency must be bounded

Do not convert a working reactive chain into imperative-style nested callbacks.

## Combining calls

Use `Mono.zip` or `zipWhen` when independent async results must be combined.

Use `flatMap` when a subsequent async operation depends on a previous result.

Use `Flux.fromIterable(...).flatMap(...)` for per-item async enrichment.
Set concurrency deliberately when external services are involved.

Do not silently drop elements because of an arbitrary concurrency limit.

## Empty publishers

Use `switchIfEmpty` only when empty is semantically meaningful.

Do not confuse:
- empty response
- null field
- error response

## Error handling

Preserve domain/business exceptions where required.

Use `onErrorResume` only for intentional recovery.

Do not convert every exception to a generic one if callers depend on the original type/body.

Avoid broad `onErrorResume(Throwable.class, ...)` unless explicitly justified.

## Reactor Context

If session, token, trace, or request metadata is stored in Reactor Context:
- preserve it through the full chain
- use `deferContextual` where values are read
- do not replace context propagation with mutable static/thread-local state

## WebClient

- Keep it non-blocking.
- Handle non-2xx responses deliberately.
- Map payloads at the adapter boundary.
- Configure timeouts through project-standard configuration.
- Do not create a new WebClient per request unless there is a strong reason.
