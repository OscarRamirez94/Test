---
name: java-junit-reactor-testing
description: Create and refactor unit tests for Java, Spring Boot, WebFlux, Reactor, JUnit 5, Mockito, StepVerifier, ports/adapters, use cases, controllers, mappers, and error scenarios.
---

# Java Testing

Use this skill whenever production code is created or refactored.

## Preferred stack

- JUnit 5
- Mockito
- Reactor Test
- StepVerifier

Follow the project's established test conventions first.

## What to test

For use cases:
- success
- empty publisher
- fallback path
- expected business exception
- downstream adapter error
- important port interactions

For adapters:
- request mapping
- response mapping
- non-2xx/error behavior
- malformed or unexpected payloads when relevant

For mappers:
- normal mapping
- null/optional fields when supported
- special/default values

For controllers:
- request validation
- headers/path variables
- response status/body
- delegated interaction

## Reactive tests

Prefer:

```java
StepVerifier.create(useCase.execute(request))
    .expectNext(expected)
    .verifyComplete();
```

For errors:

```java
StepVerifier.create(useCase.execute(request))
    .expectError(ExpectedException.class)
    .verify();
```

Avoid `block()` merely to simplify tests.

## Mockito

Verify only meaningful interactions.

Do not over-specify implementation details that make tests brittle.

Do not weaken assertions just to make a refactor pass.

When code behavior intentionally changes, update tests to describe the new contract.
