---
name: openapi-api-contracts
description: Create and maintain OpenAPI documentation for Spring Boot endpoints, including headers, path/query parameters, request/response schemas, examples, status codes, and reactive controllers.
---

# OpenAPI Contracts

Use this skill when creating or changing an endpoint.

Keep documentation synchronized with actual behavior.

Document:
- path parameters
- query parameters
- required headers
- request body
- success response
- relevant error responses
- field examples when useful

Do not document a request body for a GET endpoint unless the API truly requires one.

When changing DTOs, check whether OpenAPI examples and schemas also need updates.

Prefer existing project annotations/conventions before introducing new documentation styles.
