# Project Architecture Map

> Run the `architecture-scanner` agent once to populate this file from the actual repository.
