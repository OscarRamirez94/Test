# Copilot Java Agents

Copy/extract this ZIP into the repository root.

Structure:

.github/
  agents/
    architecture-scanner.agent.md
    spring-hexagonal.agent.md
    feature-developer.agent.md
    reactive-debugger.agent.md
    java-test.agent.md
  context/
    architecture.md

First run `architecture-scanner` and ask it to generate/update the project architecture map.
After that, use the specialized agents for normal work.
