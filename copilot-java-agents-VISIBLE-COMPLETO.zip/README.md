# Copilot Java / Spring / WebFlux Agent Pack

Complete pack for a Java backend using hexagonal architecture and reactive programming.

## Agents

- `architecture-scanner`: one-time/occasional architecture discovery and map refresh.
- `feature-developer`: new endpoints, REST/SOAP integrations and feature implementation.
- `spring-hexagonal`: architecture review and refactoring.
- `reactive-debugger`: Reactor/WebFlux debugging.
- `java-test`: JUnit/Mockito/StepVerifier testing.

## Shared context

`.github/context/architecture.md` is generated/populated by `architecture-scanner` and used as the primary navigation map by the other agents.

## Prompt templates

`.github/prompts/` contains ready-to-use prompts for architecture scanning, feature development, reactive debugging, refactoring and tests.

See `INSTALL.md` for setup and first-use instructions.
