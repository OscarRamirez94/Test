#!/bin/sh
set -e
mkdir -p .github/agents .github/context .github/prompts
cp agents/*.md .github/agents/
cp context/*.md .github/context/
cp prompts/*.md .github/prompts/
echo "Installed into .github/"
