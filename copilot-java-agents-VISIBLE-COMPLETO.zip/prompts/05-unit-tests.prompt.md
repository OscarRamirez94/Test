# Create focused Java tests

Use the `java-test` agent.

Target:
[CLASS OR METHOD]

Requirements:
- Read `.github/context/architecture.md` first.
- Follow existing test conventions.
- Use JUnit 5 / Mockito / StepVerifier as appropriate.
- Mock ports for use-case tests.
- Do not load Spring context unless necessary.
- Run only the narrowest relevant tests first.
