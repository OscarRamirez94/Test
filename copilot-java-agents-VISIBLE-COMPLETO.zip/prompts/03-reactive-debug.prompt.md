# Debug a reactive flow

Use the `reactive-debugger` agent.

Problem:
[DESCRIBE PROBLEM]

Start at:
[CLASS OR METHOD]

Requirements:
- Read `.github/context/architecture.md` first.
- Follow only the relevant reactive chain.
- Find the root cause before changing code.
- Do not use block(), manual subscribe(), sleeps or arbitrary retries as a fix.
- Apply the smallest correct change.
