# Review/refactor hexagonal architecture

Use the `spring-hexagonal` agent.

Target:
[CLASS / PACKAGE / FLOW]

Goal:
[DESCRIBE REFACTOR]

Requirements:
- Read `.github/context/architecture.md` first.
- Preserve dependency direction.
- Avoid infrastructure leakage into domain/application.
- Make the smallest viable change.
- Do not refactor unrelated code.
