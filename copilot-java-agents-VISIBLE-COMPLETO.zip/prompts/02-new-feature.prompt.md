# Implement a new feature

Use the `feature-developer` agent.

Feature:
[DESCRIBE FEATURE]

Requirements:
- Read `.github/context/architecture.md` first.
- Use the closest existing implementation as the pattern.
- Preserve hexagonal boundaries and reactive behavior.
- Explore only files necessary for this feature.
- Do not perform unrelated refactors.
- Run focused tests after implementation.
