# Scan project architecture

Use the `architecture-scanner` agent.

Analyze this repository and create/update `.github/context/architecture.md`.

Requirements:
- Determine the actual architecture from source code.
- Identify modules, layers, main flows, ports, adapters and external integrations.
- Identify reactive and testing conventions.
- Prefer symbol/reference search over reading every file.
- Do not modify production code.
- Keep the generated map compact enough to be reused as context by other agents.
