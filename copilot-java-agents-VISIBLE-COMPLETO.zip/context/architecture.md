# Project Architecture Map

> This file is the shared architectural context for the specialized Copilot agents.
> Run `architecture-scanner` first and ask it to populate/update this document from the actual repository.

## Stack
<!-- Java version, Spring Boot, build tool, Reactor/WebFlux, major libraries -->

## Modules and layers
<!-- Important modules/packages and their responsibilities -->

## Dependency direction
<!-- Actual dependency direction between domain/application/infrastructure -->

## Main flows
<!-- Compact trees, e.g. Controller -> UseCase -> Port -> Adapter -> External System -->

## Ports and adapters
<!-- Port -> implementation relationships -->

## External integrations
<!-- REST, SOAP, Redis, database, messaging, etc. -->

## Reactive conventions
<!-- Mono/Flux composition, error handling, context, schedulers -->

## Testing conventions
<!-- JUnit, Mockito, StepVerifier, naming and test organization -->

## Naming and implementation conventions
<!-- Project-specific conventions future agents should follow -->

## Architectural deviations / risks
<!-- Concrete findings only -->

## Navigation index
<!-- Concept -> package/class mappings for fast lookup -->
