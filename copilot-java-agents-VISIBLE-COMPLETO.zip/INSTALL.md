# Installation

Copy the `.github` directory into the root of your Java repository.

Expected structure:

.github/
  agents/
    architecture-scanner.agent.md
    spring-hexagonal.agent.md
    feature-developer.agent.md
    reactive-debugger.agent.md
    java-test.agent.md
  context/
    architecture.md
  prompts/
    01-scan-architecture.prompt.md
    02-new-feature.prompt.md
    03-reactive-debug.prompt.md
    04-refactor-hexagonal.prompt.md
    05-unit-tests.prompt.md

## First use

1. Open the repository in IntelliJ.
2. Sign in to GitHub Copilot.
3. Select `architecture-scanner`.
4. Ask it to execute the architecture scan prompt.
5. Verify that `.github/context/architecture.md` was populated.
6. For normal work, select the specialized agent for the task.

The architecture map is a navigation aid. Source code remains authoritative.
Refresh the map after significant architectural changes.
