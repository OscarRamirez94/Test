# Spec-Driven Java Add-on for GitHub Copilot / IntelliJ

Este paquete agrega una Skill `spec-driven-java` y plantillas para iniciar cambios por especificación.

## Instalación

Copia:

`github-skills/spec-driven-java/`

a:

`.github/skills/spec-driven-java/`

en tu repositorio.

Las plantillas dentro de `spec-templates/` son opcionales. Puedes guardarlas donde prefieras o usarlas como referencia.

## Cómo usarlo

Para un cambio importante, puedes decirle al Agent normal de Copilot:

"Usa desarrollo Spec-Driven para este cambio. Primero genera la spec, después analiza el proyecto y dame el plan. No modifiques archivos hasta que revise el plan."

Después describes la regla de negocio en español.

## Flujo esperado

SPEC
→ análisis del repositorio
→ PLAN
→ tu revisión/aprobación
→ implementación
→ tests
→ code review

## Diagramas

La Skill indica explícitamente que no deben generarse diagramas salvo que tú los pidas.

## Plantillas incluidas

- `new-flow-spec.md`
- `refactor-existing-flow-spec.md`
- `quick-spec-prompt-es.md`
- `example-refactor-spec-es.md`
