# Prompt rápido para Copilot

Usa desarrollo Spec-Driven para este cambio.

Primero crea una especificación breve con:
- objetivo
- comportamiento actual
- comportamiento solicitado
- reglas de negocio
- entradas y salidas
- comportamiento para vacío/no encontrado
- comportamiento de errores
- compatibilidad
- criterios de aceptación
- no objetivos

Después analiza el flujo real del proyecto y los patrones existentes.

Luego presenta un plan técnico antes de modificar archivos.

Cuando apruebe el plan, implementa de forma incremental, actualiza los tests y haz una revisión final contra los criterios de aceptación.

No generes diagramas salvo que yo lo pida explícitamente.

Requerimiento:

[ESCRIBE AQUÍ TU NECESIDAD]
