# Feature / Change

## Objective
Describe the new business capability in one or two sentences.

## Current Behavior
Describe what exists today, if anything.

## Requested Behavior
Describe the new end-to-end behavior without prescribing implementation details.

## Business Rules
1.
2.
3.

## Inputs
- Endpoint / entry point:
- Path parameters:
- Query parameters:
- Headers:
- Request body:
- Data coming from previous service calls:

## Outputs
- Expected response:
- New fields:
- Mapping/format requirements:

## Error and Empty Behavior
- Not found:
- Empty downstream response:
- Business error:
- Technical/downstream error:

## Compatibility
- Existing contracts that must remain unchanged:
- Existing behavior that must remain unchanged:

## Acceptance Criteria
- [ ]
- [ ]
- [ ]

## Non-Goals
- Things that should not be changed as part of this work.

## Open Questions
- Only genuinely blocking questions.
