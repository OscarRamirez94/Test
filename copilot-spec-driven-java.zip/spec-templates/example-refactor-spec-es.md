# Refactor: enriquecer respuesta con detalle

## Objective
Agregar información de detalle a un flujo existente sin romper el contrato actual.

## Current Behavior
El endpoint obtiene la información principal y devuelve la respuesta actual.

## Requested Behavior
Después de obtener el resultado principal, consultar un segundo servicio usando el identificador obtenido del primer resultado y agregar el detalle al response.

## Business Rules
1. La segunda consulta solo ocurre después de obtener correctamente el identificador.
2. Si el servicio de detalle no devuelve información, el flujo continúa con el detalle vacío.
3. Si ocurre un error técnico, se conserva la estrategia de manejo de errores actual del proyecto.
4. El flujo debe mantenerse completamente reactivo.

## Inputs
- Endpoint existente.
- Identificador proveniente de la primera consulta.

## Outputs
- Respuesta actual enriquecida con el nuevo detalle.

## Error and Empty Behavior
- Sin detalle: continuar sin fallar.
- Error técnico: conservar manejo actual.

## Compatibility
- Mantener los campos existentes.
- Mantener status codes y formato de errores salvo cambio explícito.

## Acceptance Criteria
- [ ] El segundo servicio recibe el identificador correcto.
- [ ] La respuesta incluye el detalle cuando existe.
- [ ] El flujo continúa cuando el detalle está vacío.
- [ ] No se introduce block() ni subscribe() en el flujo de negocio.
- [ ] Los tests existentes siguen pasando.
- [ ] Se agregan o actualizan tests del nuevo comportamiento.

## Non-Goals
- Refactorizar componentes no relacionados.
- Cambiar contratos externos no solicitados.
