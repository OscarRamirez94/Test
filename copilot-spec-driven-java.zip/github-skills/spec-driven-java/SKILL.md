---
name: spec-driven-java
description: Drive Java/Spring changes from a lightweight specification before planning and implementation. Use for non-trivial refactors and new flows where business rules, integrations, contracts, or acceptance criteria must be clarified first.
---

# Spec-Driven Java

Use this skill for non-trivial:
- new endpoints
- new business flows
- new REST/SOAP/Redis integrations
- changes that add business rules
- multi-file refactors
- changes that affect API contracts
- changes that require coordinated production code and tests

Do NOT require a full specification for trivial edits such as:
- typo fixes
- import cleanup
- simple renames
- obvious one-line bug fixes
- formatting-only changes

## Workflow

Follow this sequence:

SPEC
→ ANALYZE REPOSITORY
→ PLAN
→ USER REVIEW / APPROVAL
→ IMPLEMENT
→ TEST
→ CODE REVIEW

Do not skip directly from a vague requirement to broad implementation.

## SPEC phase

The specification describes WHAT the system must do.

Do not prematurely prescribe:
- Reactor operators
- concrete class names
- package names
- ports/adapters to create
- implementation libraries
- refactoring mechanics

Those belong in the PLAN phase unless the user explicitly requires them.

Build the spec from the user's business description and current behavior.

Capture:
- objective
- current behavior
- requested behavior
- business rules
- inputs
- outputs
- success behavior
- empty/not-found behavior
- technical-error behavior
- compatibility constraints
- acceptance criteria
- explicit non-goals
- open questions only when genuinely blocking

## Repository analysis

After the spec exists:

1. Locate the actual entry point.
2. Trace the current end-to-end flow.
3. Find the closest analogous implementation.
4. Read relevant project conventions and knowledge files if available.
5. Verify business assumptions against source code.
6. Identify affected tests and API documentation.

Source code remains the source of truth.

## PLAN phase

The plan describes HOW the specification will be implemented in this repository.

The plan should identify:
- existing classes to modify
- new classes only if necessary
- use cases
- ports
- adapters
- DTOs and mappers
- REST/SOAP/Redis integrations
- reactive composition strategy
- error handling
- OpenAPI impact
- tests
- risks and compatibility considerations

Use:
- existing architecture
- existing naming
- existing patterns
- existing error strategy
- existing testing style

Do not invent a parallel architecture.

## Approval behavior

For broad or architectural changes:
- present the plan before implementation
- respect normal IDE/Copilot approval and confirmation controls
- do not bypass confirmations
- do not perform destructive operations automatically

## IMPLEMENT phase

Implement incrementally.

Preserve:
- business behavior not targeted by the spec
- public contracts unless the spec changes them
- reactive non-blocking semantics
- architecture boundaries

Do not generate or update diagrams unless the user explicitly asks for one.

## TEST phase

Validate acceptance criteria through tests.

Prefer the project's existing testing approach.

For reactive Java:
- JUnit 5
- Mockito
- StepVerifier

Cover relevant success, empty, fallback and error scenarios.

## REVIEW phase

Review the resulting diff against the spec.

Check:
- every acceptance criterion
- regressions
- reactive correctness
- architecture
- error behavior
- API compatibility
- tests
- security concerns when external inputs/integrations changed

## Lightweight spec format

Use this structure:

# Feature / Change

## Objective
What outcome is required.

## Current Behavior
What the system does today.

## Requested Behavior
What must change.

## Business Rules
Numbered rules.

## Inputs
Relevant request fields, headers, path/query parameters, IDs, or upstream data.

## Outputs
Expected response/result changes.

## Error and Empty Behavior
Expected behavior for not-found, empty results, business errors and technical errors.

## Compatibility
Contracts or behavior that must remain unchanged.

## Acceptance Criteria
Testable statements.

## Non-Goals
What is intentionally out of scope.

## Open Questions
Only include questions that block a correct implementation.
